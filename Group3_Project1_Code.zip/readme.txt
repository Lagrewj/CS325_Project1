CS 325 Project 1 Maximum Sum Sub-Array

Project 1
Project Group 3 CS325 SU2015
Author: Jonathan Lagrew, Tri-Solomon Huynh, Yunsik Choi

How to use our program:

#1 Compile the program with the make file and run the program with the ./maxSubArray command.


#2 Select a menu choice option. 
	
#3	a. Choosing the option with the MSS_Problems.txt file.
	
	b. Choosing the option with the n amount of random values.
	
#4 All output will be in MSS_Results.txt.

#5 Run time output to the screen.